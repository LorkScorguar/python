package com.deskpets.android.deskpets;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class alertAudibleSelection extends Activity{

	public static boolean fromGuide = false;

    @Override
    	public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.alertaudibleselection);
    	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    	setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    	
    	fromGuide = myController.fromGuide;
    	
    	//Product Code OK button
		final Button OK = (Button) findViewById(R.id.audibleSelectionOKButton);
		
		OK.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub

				
				if(fromGuide){
					startActivity(new Intent("com.deskpets.android.test.userGuidePage"));
					fromGuide = false;
				}
				else{
					startActivity(new Intent("com.deskpets.android.test.selectionPage"));
				}
				
				
			}
			
		});
    }
}
