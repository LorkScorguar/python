package com.deskpets.android.deskpets;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;


public class termsAndConditions extends Activity{
	 /** Called when the activity is first created. */
    @Override
    	public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.termsandconditions);
    	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    	setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    	Button agree = (Button) findViewById(R.id.termsAndConditionAgreeButton);
    	Button cancel = (Button) findViewById(R.id.termsAndConditionCancelButton);
    	
		//setting up the locale and text
		TextView title = (TextView)findViewById(R.id.title);
		TextView termsAndConditions = (TextView)findViewById(R.id.termsAndConditions);
		
		title.setText(this.getString(R.string.termsAndConditionsTitleKey));
		termsAndConditions.setText(this.getString(R.string.termsAndConditionsTextKey));
		agree.setText(this.getString(R.string.termsAndConditionsAgreeButtonKey));
		cancel.setText(this.getString(R.string.termsAndConditionsCancelButtonKey));
		//end of setting up the locale and text
    	
    	
    	//agree button
		agree.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				startActivity(new Intent("com.deskpets.android.test.settingPage"));
	
			}
			
		});
		
		
    	//cancel button
    	
		
		cancel.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				finish();
			}
			
		});
    	
    	
    }
}
