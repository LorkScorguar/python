package com.deskpets.android.deskpets;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class userGuidePage extends Activity {
	TextView myTextView;
	TextView userGuideDescriptionTextView;
	ImageView myImage; 
	Button next;
	Button help;
	public static int userGuidePageCounter = 1;
	
	  @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        
	        
	        
	        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
	        setContentView(R.layout.userguidepage);
	        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
	        myTextView = (TextView) findViewById(R.id.userGuideHeading); 
	        userGuideDescriptionTextView = (TextView) findViewById(R.id.userGuideDescription);
	        myImage = (ImageView) findViewById(R.id.userGuideImage);
			next = (Button) findViewById(R.id.userGuideNextButton);
			Button home = (Button) findViewById(R.id.userGuideHomeButton);
			help = (Button) findViewById(R.id.helpButton);
			help.setVisibility(View.GONE);
			setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
			changeInformation(userGuidePageCounter);
			
			//setting up the locale and text

			TextView userGuideTitle = (TextView)findViewById(R.id.UserGuideTitle);
			
			userGuideTitle.setText(this.getString(R.string.userGuideTitleKey));
			home.setText(this.getString(R.string.userGuideHomeButtonKey));
			next.setText(this.getString(R.string.userGuideNextButtonKey));
			myTextView.setText(this.getString(R.string.userGuideTextViewTitle_1Key));
			userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_1Key));
			//end of setting up the locale and text
			
			
			

			
			next.setOnClickListener(new View.OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					userGuidePageCounter = userGuidePageCounter + 1;
					
					changeInformation(userGuidePageCounter);
				}
				
			});
	        
			home.setOnClickListener(new View.OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					startActivity(new Intent("com.deskpets.android.test.productSelection"));
				}
				
			});
	        
			help.setOnClickListener(new View.OnClickListener() {
				
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					if(userGuidePageCounter == 3){
						startActivity(new Intent("com.deskpets.android.test.settingPage"));
					}
					else if(userGuidePageCounter == 4){
						startActivity(new Intent("com.deskpets.android.deskpets.productCode"));
					}
					else if(userGuidePageCounter == 5){
						startActivity(new Intent("com.deskpets.android.deskpets.alertAudibleSelection"));
					}
				
					
				}
				
			});
			
	        
	        
	        
	    }
	  
	  

	  
	  private void changeInformation(int counter){
		  

		  
		  
			//  int source = R.drawable.userguidepic4;
			 // AssetFileDescriptor afd;
			  
			 
			//myImage = new ImageView(this);
			  
				switch(counter){
				case 1:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_1Key));
					next.setText(this.getString(R.string.userGuideNextButtonKey));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_1Key));
					//source = R.drawable.userguidepic1;
					myImage.setImageResource(R.drawable.androidcontroller2 );
					break;
				case 2:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_2Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_2Key));
					//source = R.drawable.userguidepic2;
					myImage.setImageResource(R.drawable.userguidepic2 );
					break;
				case 3:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_3Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_3Key));
					help.setVisibility(View.VISIBLE);
					//source = R.drawable.userguidepic2;
					myImage.setImageResource(R.drawable.userguidepic3 );
					break;
				case 4:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_4Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_4Key));
					help.setVisibility(View.VISIBLE);
					myImage.setImageResource(R.drawable.userguidepic4 );
					break;
				case 5:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_15Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_15Key));
					help.setVisibility(View.VISIBLE);
					myImage.setImageResource(R.drawable.userguidepic15 );
					break;
				case 6:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_5Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_5Key));
					help.setVisibility(View.GONE);
					myImage.setImageResource(R.drawable.userguidepic5 );
					break;
				case 7:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_6Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_6Key));
					myImage.setImageResource(R.drawable.userguidepic6 );
					break;
				case 8:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_7Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_7Key));
					myImage.setImageResource(R.drawable.userguidepic7 );
					break;
				case 9:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_8Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_8Key));
					myImage.setImageResource(R.drawable.userguidepic8 );
					break;
				case 10:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_9Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_9Key));
					myImage.setImageResource(R.drawable.userguidepic9 );
					break;
				case 11:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_10Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_10Key));
					myImage.setImageResource(R.drawable.userguidepic10 );
					break;
				case 12:
					myTextView.setText(this.getString(R.string.userGuideTextViewTitle_11Key));
					userGuideDescriptionTextView.setText(this.getString(R.string.userGuideTextView_11Key));
					myImage.setImageResource(R.drawable.userguidepic11 );
					break;
				}
				
				
				
				
				
				//afd = this.getResources().openRawResourceFd(source);  
				
				
				
				
			if(counter == 12){
					userGuidePageCounter = 0;
					next.setText(this.getString(R.string.userGuideAgainButtonKey));
			}
		  }
	
	
}
