package com.deskpets.android.deskpets;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class selectionPage extends Activity implements View.OnClickListener{
	public static int productID;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.selectionpage);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		//setting up the locale and text
		TextView selectionPageTitle = (TextView)findViewById(R.id.selectionPageTitle);
		TextView scrollNotice = (TextView)findViewById(R.id.scrollNotice);
		
		selectionPageTitle.setText(this.getString(R.string.selectionPageTitleKey));
		scrollNotice.setText(this.getString(R.string.selectionPageScrollNoticeKey));
		//end of setting up the locale and text
		
		//skitterbot buttons
		Button RedSkitter = (Button) findViewById(R.id.redSkitter);
		Button BlueSkitter = (Button) findViewById(R.id.blueSkitter);
		Button WhiteSkitter = (Button) findViewById(R.id.whiteSkitter);
		Button GreenSkitter = (Button) findViewById(R.id.greenSkitter);
		
		//trekbots buttons
		Button blueTrek = (Button) findViewById(R.id.blueTrek);
		Button blackTrek = (Button) findViewById(R.id.blackTrek);
		Button whiteTrek = (Button) findViewById(R.id.whiteTrek);
		Button clearTrek = (Button) findViewById(R.id.clearTrek);
		Button redTrek = (Button) findViewById(R.id.redTrek);
		Button yellowTrek = (Button) findViewById(R.id.yellowTrek);
		
		//Tanks Button
		Button orangeTank = (Button) findViewById(R.id.orangeTank);
		Button greenTank = (Button) findViewById(R.id.greenTank);
		Button blueTank = (Button) findViewById(R.id.blueTank);
		Button blackTank = (Button) findViewById(R.id.blackTank);
		
		
		
		RedSkitter.setOnClickListener(this);
		BlueSkitter.setOnClickListener(this);
		WhiteSkitter.setOnClickListener(this);
		GreenSkitter.setOnClickListener(this);
		blueTrek.setOnClickListener(this);

		blackTrek.setOnClickListener(this);
		whiteTrek.setOnClickListener(this);
		clearTrek.setOnClickListener(this) ;
		redTrek.setOnClickListener(this);
		yellowTrek.setOnClickListener(this);
		
		orangeTank.setOnClickListener(this);
		greenTank.setOnClickListener(this) ;
		blueTank.setOnClickListener(this);
		blackTank.setOnClickListener(this);
		

		
	}
	
	
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch(v.getId()){
		case R.id.redSkitter:
			productID = 11;
			break;
			
		case R.id.blueSkitter:
			productID = 12;
			break;
		case R.id.whiteSkitter:
			productID = 13;
			break;
		case R.id.greenSkitter:
			productID = 14;
			break;
		case R.id.blueTrek:
			productID = 21;
			break;
			
		case R.id.blackTrek:
			productID = 22;
			break;
		case R.id.whiteTrek:
			productID = 23;
			break;
		case R.id.clearTrek:
			productID = 24;
			break;
		case R.id.redTrek:
			productID = 25;
			break;
		case R.id.yellowTrek:
			productID = 26;
			break;
		
		case R.id.orangeTank:
			productID = 31;
			break;
		case R.id.greenTank:
			productID = 32;
			break;
		case R.id.blueTank:
			productID = 33;
			break;
		case R.id.blackTank:
			productID = 34;
			break;
			
		
		}
		
		startActivity(new Intent("com.deskpets.android.test.productSelection"));
	}
	


	
}


