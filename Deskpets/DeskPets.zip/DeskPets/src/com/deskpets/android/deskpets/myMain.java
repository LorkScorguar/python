/*  

	This is the Desk Pets Android Open Source Project which is an android app
	that it is used to control the Desk Pets products.
    Copyright (C) 2011  Eric Poon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/



package com.deskpets.android.deskpets;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.WindowManager;

public class myMain extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
		Thread logoTimer = new Thread(){
			public void run(){
				try{
					int logoTimer = 0;
					while(logoTimer < 3000){
						sleep(100);
						logoTimer = logoTimer + 100;
					}
					setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
				//	startActivity(new Intent("com.deskpets.android.deskpets.setOrientation"));
				//	startActivity(new Intent("com.deskpets.android.test.portrait"));
					startActivity(new Intent("com.deskpets.android.deskpets.CLEARSCREEN"));
				//	startActivity(new Intent("com.deskpets.android.deskpets.termsAndConditions"));
				//	startActivity(new Intent("com.deskpets.android.test.settingPage"));
				} 
				catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				finally{
					finish();
				}
			}
			
		};
		
		logoTimer.start();
        
        
        
        
    }
}