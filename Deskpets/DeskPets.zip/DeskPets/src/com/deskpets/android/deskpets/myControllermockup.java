package com.deskpets.android.deskpets;



import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class myControllermockup extends Activity{
	
	public static int product;
	public static int command;
	public static int codeType;
	public static boolean firstTime = true;
	public static boolean buttonSoundAlert = true;
	public int playOrNot = 1;
	public static boolean fromGuide = false;
	public static int counter;
	public static String URLLink;
	
	public MediaPlayer mp;
	TextView testTextView;
	
	Button fire;
	
	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		
		
		setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		

		String code = productCode.code;
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		product = selectionPage.productID;
		codeType = settingPage.code;
		mp = new MediaPlayer();
		fire = (Button) findViewById(R.id.buttonFire);
		fire.setVisibility(View.GONE);
		TextView myTextView = (TextView) findViewById(R.id.versionName); 
		fromGuide = false;
		Button URLButton = (Button) findViewById(R.id.URLButton);
		Button userGuide = (Button) findViewById(R.id.userGuideButton);
		Button productSelection = (Button) findViewById(R.id.selectionButton);
		//AbsoluteLayout theMainLayout = (AbsoluteLayout) findViewById(R.id.mainThing);
		
		//setting up the locale and text
		TextView URL = (TextView) findViewById(R.id.URL);
		//LayoutParams params = (android.widget.RelativeLayout.LayoutParams) this.generateDefaultLayoutParams();
		
		URL.setText(this.getString(R.string.myControllerURLKey));
		URLLink = this.getString(R.string.myControllerURLLinkKey);
		
		//end of setting up the locale and text
		
		
		
		
		//setting up layout scaling according to screen size
		//Display display = getWindowManager().getDefaultDisplay(); 
		//int screenWidth = display.getWidth();
		//int screenHeight = display.getHeight();
		
		TextView textViewTesting = (TextView) findViewById(R.id.blackTank);
		TextView ButtonTitleChanging = (TextView) findViewById(R.id.buttonFire);
		//end of setting up layout scaling according to screen size
		
		
		
		
		
		
		
        // Get the app's shared preferences
        final SharedPreferences app_preferences = 
        	PreferenceManager.getDefaultSharedPreferences(this);
        
        // save the value of the counter, counter = product (productID)
        //save the value of the product code
        SharedPreferences.Editor editor = app_preferences.edit();
        editor.putInt("counter", product);
        editor.putString("productCode", code);
        editor.commit(); // Very important
        
        // Get the value for the run counter
        int counter = app_preferences.getInt("counter", 0);
        String productCodeFromMemory = app_preferences.getString("productCode", "0");

        
        
        // Update the TextView
        
       // myTextView.setText("T " + productCodeFromMemory + " times.");
        
        

        
        
        //if counter is nothing, goes to the terms and condition page
        if(counter == 0){
        	startActivity(new Intent("com.deskpets.android.deskpets.termsAndConditions"));
        	
        }
		
		
		//for setting up the URL at the bottom
		
		
		URLButton.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Uri uriUrl = Uri.parse(URLLink);
				Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl); 
				startActivity(launchBrowser);  
				
			}
			
		});
		
		
	//	firstTime = savedInstanceState.getBoolean("firstTime");
		
		
		if (code.equals("1890") ||
				code.equals("1880") ||
				code.equals("1870") ||
				code.equals("1860")  ){
			//myTextView.setText("My double value is " + code);
			
			if(product > 30 && product < 40 ){
				fire.setVisibility(View.VISIBLE);
			}
			
			
			
		}
		else if(productCodeFromMemory.equals("1890") ||
				productCodeFromMemory.equals("1880") ||
				productCodeFromMemory.equals("1870") ||
				productCodeFromMemory.equals("1860") ){
			//myTextView.setText("My double value is " + code);
			
			if(product > 30 && product < 40 ){
				fire.setVisibility(View.VISIBLE);
			}
		}
		else{
			//myTextView.setText("There is nothing.");
			
			fire.setVisibility(View.GONE);
		
		}
		
		if(firstTime){
			
			//myTextView.setText("MyfirstTIme");
		}
		
		//alert view
		/*
		AlertDialog.Builder alt_bld = new AlertDialog.Builder(this);
		alt_bld.setMessage("To optimize the app performance, make sure the button sound effect of the phone is disabled. Please go to 'setting' --> 'sound', uncheck the box 'Audible selection'. ")
		.setCancelable(false)

		.setNegativeButton("OK", new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int id) {
		//  Action for 'NO' Button
			
		dialog.cancel();
		}
		});
		AlertDialog alert = alt_bld.create();
		// Title for AlertDialog
		alert.setTitle("Disable the button sound");
		// Icon for AlertDialog
		alert.setIcon(R.drawable.deskpetsicon);
		if(buttonSoundAlert){
			alert.show();
			buttonSoundAlert = false;
		}
		*/
		//alert View end
		
		
		
	
		
		
		//TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("My double value is "+ product + command);

				
		//selection button
		
		
		productSelection.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				startActivity(new Intent("com.deskpets.android.test.selectionPage"));
			}
			
		});
		
		//User Guide button

		userGuide.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				fromGuide = true;
				startActivity(new Intent("com.deskpets.android.test.userGuidePage"));
			}
			
		});
		
		//set up the button sound
		//final MediaPlayer upSound = MediaPlayer.create(this, R.raw.fwdblacktrekflip);
		
		//Button Fire

		fire.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				command = 10;
				playSound(product, command);

			}
			
		});
		
		
		
		//Button android head
		Button androidHead = (Button) findViewById(R.id.androidHead);
		
		androidHead.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				command = 1;
				playSound(21, command);
				
			}
			
		});
		
		
		//Button android right hand
		Button androidRightHand = (Button) findViewById(R.id.androidRightHand);
		
		androidRightHand.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				command = 4;
				playSound(21, command);
				
			}
			
		});
		
		
		//Button android left hand
		Button androidLeftHand = (Button) findViewById(R.id.androidLeftHand);
		
		androidLeftHand.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				command = 3;
				playSound(21, command);
				
			}
			
		});
		
		
		//Button android body
		Button androidBody = (Button) findViewById(R.id.androidBody);
		
		androidBody.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				command = 2;
				playSound(21, command);
				
			}
			
		});
		
		
		
		
		//Button up
		Button up = (Button) findViewById(R.id.buttonUp);
		
		up.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub


				//startActivity(new Intent("com.deskpets.android.deskpets.test"));

	
				
			//	upSound.start();
				command = 1;
				playSound(25, command);
				
				/*
				new Handler().postDelayed(new Runnable() { 
	                public void run() {
	                	playSound(product, command);
	                } 
	}, 200);
				*/
			}
			
		});

		
		//Button down
		Button down = (Button) findViewById(R.id.buttonDown);
		
		down.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
			
				

				
				
				command = 2;
				playSound(25, command);
				
				/*
				new Handler().postDelayed(new Runnable() { 
	                public void run() {
	                	playSound(product, command);
	                } 
	}, 200);
		*/
			}
			
		});
		
		
	
		//Button left
		Button left = (Button) findViewById(R.id.buttonLeft);
		
		left.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
	
				
				if(product >30 && product < 40){
					if(command == 2){
						command = 6;
					
					}
					else{
						command = 5;
					}
				}
				else{
					
				command = 3;
				}
				playSound(25, command);
				
				/*
				new Handler().postDelayed(new Runnable() { 
	                public void run() {
	                	playSound(product, command);
	                } 
	}, 200);
				*/
			}
			
		});
		
		
		
		
		//Button right
		Button right = (Button) findViewById(R.id.buttonRight);
		
		right.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
	
				
				
				if(product >30 && product < 40){
					if(command == 2){
						command = 8;
					}
					else{
						command = 7;
					}
					
				}
				else{
				command = 4;
				}
				
				
				playSound(25, command);
				/*
				new Handler().postDelayed(new Runnable() { 
	                public void run() {
	                	playSound(product, command);
	                } 
	}, 200);
	*/
			}
			
		});
		
		
		
		
		//Button stop
		Button stop = (Button) findViewById(R.id.buttonStop);
		
		stop.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
			
				
				if(product >30 && product < 40){
					command = 9;
				}
				else{
					
				command = 5;
				}
				playSound(25, command);
				
				/*
				new Handler().postDelayed(new Runnable() { 
	                public void run() {
	                	playSound(product, command);
	                } 
	}, 200);
	*/
			}
			
		});
		
		
		
		
		
	}
	
private void playSound(int productNumber, int command){
	
	System.out.println("!!!!!PLAY SOUND");
	
	mp.reset();
	
	int resid=R.raw.stopredbug;
	
//	MediaPlayer sound;
	//sound = MediaPlayer.create(this, R.raw.stopredbug);
	
	AssetFileDescriptor afd;

//	sound.setDataSource(this, uri);
	try{
		
		if(codeType == 2){
		
		if(productNumber == 11 && command == 1){
			resid = R.raw.fwdredskitterflip;
			//resid = R.raw.carscreech;
			//sound = MediaPlayer.create(this, R.raw.fwdredskitterflip);
		}
		else if(productNumber == 11 && command == 2){
			//resid = R.raw.frustrated;
			resid = R.raw.bwdredskitterflip;
			//sound = MediaPlayer.create(this, R.raw.bwdredskitterflip);
		}
		else if(productNumber == 11 && command == 3){
			resid = R.raw.leftredskitterflip;
		//	sound = MediaPlayer.create(this, R.raw.leftredskitterflip);
		}
		else if(productNumber == 11 && command == 4){
			resid = R.raw.rightredskitterflip;
		//	sound = MediaPlayer.create(this, R.raw.rightredskitterflip);
		}
		else if(productNumber == 11 && command == 5){
			resid = R.raw.stopredskitterflip;
		//	sound = MediaPlayer.create(this, R.raw.stopredskitterflip);
		}
		else if(productNumber == 12 && command == 1){
			resid = R.raw.fwdbluebugflip;
		}
		else if(productNumber == 12 && command == 2){
			resid = R.raw.bwdbluebugflip;
		}
		else if(productNumber == 12 && command == 3){
			resid = R.raw.leftbluebugflip;
		}
		else if(productNumber == 12 && command == 4){
			resid = R.raw.rightbluebugflip;
		}
		else if(productNumber == 12 && command == 5){
			resid = R.raw.stopbluebugflip;
		}
		else if(productNumber == 13 && command == 1){
			resid = R.raw.fwdwhitebugflip;
		}
		else if(productNumber == 13 && command == 2){
			resid = R.raw.bwdwhitebugflip;
		}
		else if(productNumber == 13 && command == 3){
			resid = R.raw.leftwhitebugflip;
		}
		else if(productNumber == 13 && command == 4){
			resid = R.raw.rightwhitebugflip;
		}
		else if(productNumber == 13 && command == 5){
			resid = R.raw.stopwhitebugflip;
		}
		else if(productNumber == 14 && command == 1){
			resid = R.raw.fwdgreenbugflip;
		}
		else if(productNumber == 14 && command == 2){
			resid = R.raw.bwdgreenbugflip;
		}
		else if(productNumber == 14 && command == 3){
			resid = R.raw.leftgreenbugflip;
		}
		else if(productNumber == 14 && command == 4){
			resid = R.raw.rightgreenbugflip;
		}
		else if(productNumber == 14 && command == 5){
			resid = R.raw.stopgreenbugflip;
		}

		else if(productNumber == 21 && command == 1){
			resid = R.raw.fwdbluetrekflip;
		}
		else if(productNumber == 21 && command == 2){
			resid = R.raw.bwdbluetrekflip;
		}
		else if(productNumber == 21 && command == 3){
			resid = R.raw.leftbluetrekflip;
		}
		else if(productNumber == 21 && command == 4){
			resid = R.raw.rightbluetrekflip;
		}
		else if(productNumber == 21 && command == 5){
			resid = R.raw.stopbluetrekflip;
		}
		else if(productNumber == 22 && command == 1){
			resid = R.raw.fwdblacktrekflip;
		}
		else if(productNumber == 22 && command == 2){
			resid = R.raw.bwdblacktrekflip;
		}
		else if(productNumber == 22 && command == 3){
			resid = R.raw.leftblacktrekflip;
		}
		else if(productNumber == 22 && command == 4){
			resid = R.raw.rightblacktrekflip;
		}
		else if(productNumber == 22 && command == 5){
			resid = R.raw.stopblacktrekflip;
		}
		else if(productNumber == 23 && command == 1){
			resid = R.raw.fwdbluetrekflip;
		}
		else if(productNumber == 23 && command == 2){
			resid = R.raw.bwdbluetrekflip;
		}
		else if(productNumber == 23 && command == 3){
			resid = R.raw.leftbluetrekflip;
		}
		else if(productNumber == 23 && command == 4){
			resid = R.raw.rightbluetrekflip;
		}
		else if(productNumber == 23 && command == 5){
			resid = R.raw.stopbluetrekflip;
		}
		else if(productNumber == 24 && command == 1){
			resid = R.raw.fwdcleartrekflip;
		}
		else if(productNumber == 24 && command == 2){
			resid = R.raw.bwdcleartrekflip;
		}
		else if(productNumber == 24 && command == 3){
			resid = R.raw.leftcleartrekflip;
		}
		else if(productNumber == 24 && command == 4){
			resid = R.raw.rightcleartrekflip;
		}
		else if(productNumber == 24 && command == 5){
			resid = R.raw.stopcleartrekflip;
		}
		else if(productNumber == 25 && command == 1){
			resid = R.raw.fwdredtrekflip;
		}
		else if(productNumber == 25 && command == 2){
			resid = R.raw.bwdredtrekflip;
		}
		else if(productNumber == 25 && command == 3){
			resid = R.raw.leftredtrekflip;
		}
		else if(productNumber == 25 && command == 4){
			resid = R.raw.rightredtrekflip;
		}
		else if(productNumber == 25 && command == 5){
			resid = R.raw.stopredtrekflip;
		}
		else if(productNumber == 26 && command == 1){
			resid = R.raw.fwdredtrekflip;
		}
		else if(productNumber == 26 && command == 2){
			resid = R.raw.bwdredtrekflip;
		}
		else if(productNumber == 26 && command == 3){
			resid = R.raw.leftredtrekflip;
		}
		else if(productNumber == 26 && command == 4){
			resid = R.raw.rightredtrekflip;
		}
		else if(productNumber == 26 && command == 5){
			resid = R.raw.stopredtrekflip;
		}
		
		//tankbots
		else if(productNumber == 31 && command == 1){
			resid = R.raw.lfrforangetankflip;
		}
		else if(productNumber == 31 && command == 2){
			resid = R.raw.lbrborangetankflip;
		}
		else if(productNumber == 31 && command == 3){
			resid = R.raw.lbrforangetankflip;
		}
		else if(productNumber == 31 && command == 4){
			resid = R.raw.lfrborangetankflip;
		}
		else if(productNumber == 31 && command == 5){
			resid = R.raw.lsrforangetankflip;
		}
		else if(productNumber == 31 && command == 6){
			resid = R.raw.lsrborangetankflip;
		}
		else if(productNumber == 31 && command == 7){
			resid = R.raw.lfrsorangetankflip;
		}
		else if(productNumber == 31 && command == 8){
			resid = R.raw.lbrsorangetankflip;
		}
		else if(productNumber == 31 && command == 9){
			resid = R.raw.lsrsorangetankflip;
		}
		else if(productNumber == 31 && command == 10){
			resid = R.raw.fireorangetankflip;
		}
		else if(productNumber == 32 && command == 1){
			resid = R.raw.lfrfgreentankflip;
		}
		else if(productNumber == 32 && command == 2){
			resid = R.raw.lbrbgreentankflip;
		}
		else if(productNumber == 32 && command == 3){
			resid = R.raw.lbrfgreentankflip;
		}
		else if(productNumber == 32 && command == 4){
			resid = R.raw.lfrbgreentankflip;
		}
		else if(productNumber == 32 && command == 5){
			resid = R.raw.lsrfgreentankflip;
		}
		else if(productNumber == 32 && command == 6){
			resid = R.raw.lsrbgreentankflip;
		}
		else if(productNumber == 32 && command == 7){
			resid = R.raw.lfrsgreentankflip;
		}
		else if(productNumber == 32 && command == 8){
			resid = R.raw.lbrsgreentankflip;
		}
		else if(productNumber == 32 && command == 9){
			resid = R.raw.lsrsgreentankflip;
		}
		else if(productNumber == 32 && command == 10){
			resid = R.raw.firegreentankflip;
		}
		else if(productNumber == 33 && command == 1){
			resid = R.raw.lfrfbluetankflip;
		}
		else if(productNumber == 33 && command == 2){
			resid = R.raw.lbrbbluetankflip;
		}
		else if(productNumber == 33 && command == 3){
			resid = R.raw.lbrfbluetankflip;
		}
		else if(productNumber == 33 && command == 4){
			resid = R.raw.lfrbbluetankflip;
		}
		else if(productNumber == 33 && command == 5){
			resid = R.raw.lsrfbluetankflip;
		}
		else if(productNumber == 33 && command == 6){
			resid = R.raw.lsrbbluetankflip;
		}
		else if(productNumber == 33 && command == 7){
			resid = R.raw.lfrsbluetankflip;
		}
		else if(productNumber == 33 && command == 8){
			resid = R.raw.lbrsbluetankflip;
		}
		else if(productNumber == 33 && command == 9){
			resid = R.raw.lsrsbluetankflip;
		}
		else if(productNumber == 33 && command == 10){
			resid = R.raw.firebluetankflip;
		}
		else if(productNumber == 34 && command == 1){
			resid = R.raw.lfrfgreytankflip;
		}
		else if(productNumber == 34 && command == 2){
			resid = R.raw.lbrbgreytankflip;
		}
		else if(productNumber == 34 && command == 3){
			resid = R.raw.lbrfgreytankflip;
		}
		else if(productNumber == 34 && command == 4){
			resid = R.raw.lfrbgreytankflip;
		}
		else if(productNumber == 34 && command == 5){
			resid = R.raw.lsrfgreytankflip;
		}
		else if(productNumber == 34 && command == 6){
			resid = R.raw.lsrbgreytankflip;
		}
		else if(productNumber == 34 && command == 7){
			resid = R.raw.lfrsgreytankflip;
		}
		else if(productNumber == 34 && command == 8){
			resid = R.raw.lbrsgreytankflip;
		}
		else if(productNumber == 34 && command == 9){
			resid = R.raw.lsrsgreytankflip;
		}
		else if(productNumber == 34 && command == 10){
			resid = R.raw.firegreytankflip;
		}

		
		
		
		}
		
		else if(codeType == 1){
			if(productNumber == 11 && command == 1){
				resid = R.raw.fwdredbug;
				//sound = MediaPlayer.create(this, R.raw.fwdredbug);
			}
			else if(productNumber == 11 && command == 2){
				resid = R.raw.bwdredbug;
				//sound = MediaPlayer.create(this, R.raw.bwdredbug);
			}
			else if(productNumber == 11 && command == 3){
				resid = R.raw.leftredbug;
				//sound = MediaPlayer.create(this, R.raw.leftredbug);
			}
			else if(productNumber == 11 && command == 4){
				resid = R.raw.rightredbug;
				//sound = MediaPlayer.create(this, R.raw.rightredbug);
			}
			else if(productNumber == 11 && command == 5){
				resid = R.raw.stopredbug;
				//sound = MediaPlayer.create(this, R.raw.stopredbug);
			}
			else if(productNumber == 12 && command == 1){
				resid = R.raw.fwdbluebug;
			}
			else if(productNumber == 12 && command == 2){
				resid = R.raw.bwdbluebug;
			}
			else if(productNumber == 12 && command == 3){
				resid = R.raw.leftbluebug;
			}
			else if(productNumber == 12 && command == 4){
				resid = R.raw.rightbluebug;
			}
			else if(productNumber == 12 && command == 5){
				resid = R.raw.stopbluebug;
			}
			else if(productNumber == 13 && command == 1){
				resid = R.raw.fwdwhitebug;
			}
			else if(productNumber == 13 && command == 2){
				resid = R.raw.bwdwhitebug;
			}
			else if(productNumber == 13 && command == 3){
				resid = R.raw.leftwhitebug;
			}
			else if(productNumber == 13 && command == 4){
				resid = R.raw.rightwhitebug;
			}
			else if(productNumber == 13 && command == 5){
				resid = R.raw.stopwhitebug;
			}
			else if(productNumber == 14 && command == 1){
				resid = R.raw.fwdgreenbug;
			}
			else if(productNumber == 14 && command == 2){
				resid = R.raw.bwdgreenbug;
			}
			else if(productNumber == 14 && command == 3){
				resid = R.raw.leftgreenbug;
			}
			else if(productNumber == 14 && command == 4){
				resid = R.raw.rightgreenbug;
			}
			else if(productNumber == 14 && command == 5){
				resid = R.raw.stopgreenbug;
			}

			else if(productNumber == 21 && command == 1){
				resid = R.raw.fwdbluetrek;
			}
			else if(productNumber == 21 && command == 2){
				resid = R.raw.bwdbluetrek;
			}
			else if(productNumber == 21 && command == 3){
				resid = R.raw.leftbluetrek;
			}
			else if(productNumber == 21 && command == 4){
				resid = R.raw.rightbluetrek;
			}
			else if(productNumber == 21 && command == 5){
				resid = R.raw.stopbluetrek;
			}
			else if(productNumber == 22 && command == 1){
				resid = R.raw.fwdblacktrek;
			}
			else if(productNumber == 22 && command == 2){
				resid = R.raw.bwdblacktrek;
			}
			else if(productNumber == 22 && command == 3){
				resid = R.raw.leftblacktrek;
			}
			else if(productNumber == 22 && command == 4){
				resid = R.raw.rightblacktrek;
			}
			else if(productNumber == 22 && command == 5){
				resid = R.raw.stopblacktrek;
			}
			else if(productNumber == 23 && command == 1){
				resid = R.raw.fwdbluetrek;
			}
			else if(productNumber == 23 && command == 2){
				resid = R.raw.bwdbluetrek;
			}
			else if(productNumber == 23 && command == 3){
				resid = R.raw.leftbluetrek;
			}
			else if(productNumber == 23 && command == 4){
				resid = R.raw.rightbluetrek;
			}
			else if(productNumber == 23 && command == 5){
				resid = R.raw.stopbluetrek;
			}
			else if(productNumber == 24 && command == 1){
				resid = R.raw.fwdcleartrek;
			}
			else if(productNumber == 24 && command == 2){
				resid = R.raw.bwdcleartrek;
			}
			else if(productNumber == 24 && command == 3){
				resid = R.raw.leftcleartrek;
			}
			else if(productNumber == 24 && command == 4){
				resid = R.raw.rightcleartrek;
			}
			else if(productNumber == 24 && command == 5){
				resid = R.raw.stopcleartrek;
			}
			else if(productNumber == 25 && command == 1){
				resid = R.raw.fwdredtrek;
			}
			else if(productNumber == 25 && command == 2){
				resid = R.raw.bwdredtrek;
			}
			else if(productNumber == 25 && command == 3){
				resid = R.raw.leftredtrek;
			}
			else if(productNumber == 25 && command == 4){
				resid = R.raw.rightredtrek;
			}
			else if(productNumber == 25 && command == 5){
				resid = R.raw.stopredtrek;
			}
			else if(productNumber == 26 && command == 1){
				resid = R.raw.fwdredtrek;
			}
			else if(productNumber == 26 && command == 2){
				resid = R.raw.bwdredtrek;
			}
			else if(productNumber == 26 && command == 3){
				resid = R.raw.leftredtrek;
			}
			else if(productNumber == 26 && command == 4){
				resid = R.raw.rightredtrek;
			}
			else if(productNumber == 26 && command == 5){
				resid = R.raw.stopredtrek;
			}
			
			//tankbots
			else if(productNumber == 31 && command == 1){
				resid = R.raw.lfrforangetank;
			}
			else if(productNumber == 31 && command == 2){
				resid = R.raw.lbrborangetank;
			}
			else if(productNumber == 31 && command == 3){
				resid = R.raw.lbrforangetank;
			}
			else if(productNumber == 31 && command == 4){
				resid = R.raw.lfrborangetank;
			}
			else if(productNumber == 31 && command == 5){
				resid = R.raw.lsrforangetank;
			}
			else if(productNumber == 31 && command == 6){
				resid = R.raw.lsrborangetank;
			}
			else if(productNumber == 31 && command == 7){
				resid = R.raw.lfrsorangetank;
			}
			else if(productNumber == 31 && command == 8){
				resid = R.raw.lbrsorangetank;
			}
			else if(productNumber == 31 && command == 9){
				resid = R.raw.lsrsorangetank;
			}
			else if(productNumber == 31 && command == 10){
				resid = R.raw.fireorangetank;
			}
			else if(productNumber == 32 && command == 1){
				resid = R.raw.lfrfgreentank;
			}
			else if(productNumber == 32 && command == 2){
				resid = R.raw.lbrbgreentank;
			}
			else if(productNumber == 32 && command == 3){
				resid = R.raw.lbrfgreentank;
			}
			else if(productNumber == 32 && command == 4){
				resid = R.raw.lfrbgreentank;
			}
			else if(productNumber == 32 && command == 5){
				resid = R.raw.lsrfgreentank;
			}
			else if(productNumber == 32 && command == 6){
				resid = R.raw.lsrbgreentank;
			}
			else if(productNumber == 32 && command == 7){
				resid = R.raw.lfrsgreentank;
			}
			else if(productNumber == 32 && command == 8){
				resid = R.raw.lbrsgreentank;
			}
			else if(productNumber == 32 && command == 9){
				resid = R.raw.lsrsgreentank;
			}
			else if(productNumber == 32 && command == 10){
				resid = R.raw.firegreentank;
			}
			else if(productNumber == 33 && command == 1){
				resid = R.raw.lfrfbluetank;
			}
			else if(productNumber == 33 && command == 2){
				resid = R.raw.lbrbbluetank;
			}
			else if(productNumber == 33 && command == 3){
				resid = R.raw.lbrfbluetank;
			}
			else if(productNumber == 33 && command == 4){
				resid = R.raw.lfrbbluetank;
			}
			else if(productNumber == 33 && command == 5){
				resid = R.raw.lsrfbluetank;
			}
			else if(productNumber == 33 && command == 6){
				resid = R.raw.lsrbbluetank;
			}
			else if(productNumber == 33 && command == 7){
				resid = R.raw.lfrsbluetank;
			}
			else if(productNumber == 33 && command == 8){
				resid = R.raw.lbrsbluetank;
			}
			else if(productNumber == 33 && command == 9){
				resid = R.raw.lsrsbluetank;
			}
			else if(productNumber == 33 && command == 10){
				resid = R.raw.firebluetank;
			}
			else if(productNumber == 34 && command == 1){
				resid = R.raw.lfrfgreytank;
			}
			else if(productNumber == 34 && command == 2){
				resid = R.raw.lbrbgreytank;
			}
			else if(productNumber == 34 && command == 3){
				resid = R.raw.lbrfgreytank;
			}
			else if(productNumber == 34 && command == 4){
				resid = R.raw.lfrbgreytank;
			}
			else if(productNumber == 34 && command == 5){
				resid = R.raw.lsrfgreytank;
			}
			else if(productNumber == 34 && command == 6){
				resid = R.raw.lsrbgreytank;
			}
			else if(productNumber == 34 && command == 7){
				resid = R.raw.lfrsgreytank;
			}
			else if(productNumber == 34 && command == 8){
				resid = R.raw.lbrsgreytank;
			}
			else if(productNumber == 34 && command == 9){
				resid = R.raw.lsrsgreytank;
			}
			else if(productNumber == 34 && command == 10){
				resid = R.raw.firegreytank;
			}

		}
		else {
			resid = R.raw.stopredskitterflip;
		}
		
		//InputStream stream = this.getResources().openRawResource(resid); 
		
		
		afd = this.getResources().openRawResourceFd(resid);  
		
		  if(afd != null){   
		    mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());  
		    afd.close();  
		    mp.prepare();  
		  }else {
			  System.out.println("Not getting the location!!!!");
			  
		  }
		  	  
		//sound.setLooping(false);
		
	    mp.setLooping(false);
		//if(playOrNot == 1){
			////sound.start();
			mp.start();
		//	playOrNot = 0;
		//}
		//else{
		//	TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("fuck "+ playOrNot);
		
		//}

	}catch (Exception e) {
		//TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("Error "+ playOrNot); 
		System.out.println("EXCEPTION CAUGHT");
		e.printStackTrace();
		// serverPort = 80;  // default port for server 
    }
	
	mp.setOnCompletionListener(new OnCompletionListener() {

             
  /*           public void onCompletion(MediaPlayer sound) {
            	 onDestroy();
            	 //sound.release();
                 TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("My double value is "+ product);
                 playOrNot = 1;
             }*/
             
             public void onCompletion(MediaPlayer mp) {
            	 //onDestroy();
            	 //sound.release();
            	 mp.stop();
            	 
                // TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("On Completion My double value is "+ product);
                 playOrNot = 1;
             }

         });
		 
		 
	}

@Override
public void onSaveInstanceState(Bundle savedInstanceState) {
  // Save UI state changes to the savedInstanceState.
  // This bundle will be passed to onCreate if the process is
  // killed and restarted.
  savedInstanceState.putBoolean("firstTime", false);
  savedInstanceState.putDouble("myDouble", 1.9);
  savedInstanceState.putInt("MyInt", 1);
  savedInstanceState.putString("MyString", "Welcome back to Android");
  // etc.
  super.onSaveInstanceState(savedInstanceState);
}

@Override
public void onRestoreInstanceState(Bundle savedInstanceState) {
  super.onRestoreInstanceState(savedInstanceState);
  // Restore UI state from the savedInstanceState.
  // This bundle has also been passed to onCreate.
  boolean firstTime = savedInstanceState.getBoolean("firstTime");
  double myDouble = savedInstanceState.getDouble("myDouble");
  int myInt = savedInstanceState.getInt("MyInt");
  String myString = savedInstanceState.getString("MyString");
}

    @Override
    protected void onPause() {
        super.onPause();
 //       releaseMediaPlayer();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releaseMediaPlayer();

    }

    public void releaseMediaPlayer() {
        if (mp != null) {
            mp.release();
            //mp = null;
        }
    }
	
}
