package com.deskpets.android.deskpets;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

public class test extends Activity{

    @Override
    	public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    	setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    	 
    	
    	EditText ed = new EditText(this);  
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT,  
                LayoutParams.WRAP_CONTENT);  
        params.addRule(RelativeLayout.ALIGN_PARENT_LEFT);  
        // use same id as defined when adding the button  
        params.addRule(RelativeLayout.LEFT_OF, 1001);  
        ed.setLayoutParams(params);  
        ed.setHint("Enter some text....");  
  
        Button but1 = new Button(this);  
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,  
                LayoutParams.WRAP_CONTENT);  
        params2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);  
        but1.setLayoutParams(params2);  
        but1.setText("Press Here!");  
        // give the button an id that we know  
        but1.setId(1001);  
         
        RelativeLayout layout1 = new RelativeLayout(this);
        layout1.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));  
        layout1.addView(ed);  
        layout1.addView(but1);  
        setContentView(layout1);  

		
    }
}
