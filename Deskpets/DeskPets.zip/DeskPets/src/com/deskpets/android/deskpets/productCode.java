package com.deskpets.android.deskpets;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class productCode extends Activity{
	 /** Called when the activity is first created. */
	
	public static String code = "0";
	public static boolean fromGuide = false;
	
	
    @Override
    	public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.productcode);
    	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    	setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    	fromGuide = myController.fromGuide;
		final EditText productCode = (EditText) findViewById(R.id.productCodeEditText); 
		productCode.setInputType(InputType.TYPE_CLASS_PHONE);
    	
		//setting up the locale and text
		TextView title = (TextView)findViewById(R.id.title);
		TextView instruction = (TextView)findViewById(R.id.instruction);
		TextView notice = (TextView)findViewById(R.id.notice);
		
		
		title.setText(this.getString(R.string.productCodeTitleKey));
		instruction.setText(this.getString(R.string.productCodeIntroductionKey));
		notice.setText(this.getString(R.string.productCodeNoticeKey));
		//end of setting up the locale and text
    	
    	
    	
    	//Product Code OK button
		final Button OK = (Button) findViewById(R.id.productCodeOKButton);
		
		OK.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub

				
				if(fromGuide){
					startActivity(new Intent("com.deskpets.android.test.userGuidePage"));
					fromGuide = false;
				}
				else{
					startActivity(new Intent("com.deskpets.android.deskpets.alertAudibleSelection"));
				}
				
				
				

				code = productCode.getText().toString(); 
			}
			
		});
    	
    	
    	
    	
    }
	
}
