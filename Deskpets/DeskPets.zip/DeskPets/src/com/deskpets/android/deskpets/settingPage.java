package com.deskpets.android.deskpets;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;





public class settingPage extends Activity{
	 /** Called when the activity is first created. */
	public MediaPlayer mp;
	public int playOrNot = 1;
	public static int code = 1;
	public Button code1test;
	public boolean fromGuide = false;
	public static String again;
	
	
    @Override
    	public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.settingpage);
    	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    	setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    	fromGuide = myController.fromGuide;
    	Button yesButton = (Button) findViewById(R.id.settingPageYesButton);
    	Button noButton = (Button) findViewById(R.id.settingPageNoButton);
    	final Button code1test = (Button) findViewById(R.id.testCode1Button);
    	mp = new MediaPlayer();
    	
    	
		//setting up the locale and text
		TextView title = (TextView)findViewById(R.id.title);
		TextView instruction = (TextView)findViewById(R.id.instruction);
		TextView checking = (TextView)findViewById(R.id.checking);
		
		title.setText(this.getString(R.string.settingPageTitleKey));
		instruction.setText(this.getString(R.string.settingPageInstructionKey));
		checking.setText(this.getString(R.string.settingPageCheckingKey));
		code1test.setText(this.getString(R.string.settingPageTestButtonKey));
		yesButton.setText(this.getString(R.string.settingPageYesButtonKey));
		noButton.setText(this.getString(R.string.settingPageNoButtonKey));
		again = this.getString(R.string.settingPageTestAgainButtonKey);
		//end of setting up the locale and text
    	
    	
    	//Code 1 test button
		
		
		code1test.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub

				playSound(code);
			}
			
		});
		
    	//Code test Yes button
		
		
		yesButton.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
			if(fromGuide){
				startActivity(new Intent("com.deskpets.android.test.userGuidePage"));
				fromGuide = false;
			}
			else{
				startActivity(new Intent("com.deskpets.android.deskpets.productCode"));
			}
			
			
			code1test.setText("Press Me!");
			}
			
		});
		
    	//Code test No button
		
		
		noButton.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub

				
				
				if(code == 1){
					code = 2;
				}
				else{
					code = 1;
				}
				
				code1test.setText(again);
				changeCodeAlert();
				
				
			}
			
		});
    	
    }
    
    
    private void changeCodeAlert(){
    	
    	//alert view

		AlertDialog.Builder alt_bld = new AlertDialog.Builder(this);
		alt_bld.setMessage(this.getString(R.string.settingPageAlertTextKey))
		.setCancelable(false)

		.setNegativeButton("OK", new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int id) {
		//  Action for 'NO' Button
			
		dialog.cancel();
		}
		});
		AlertDialog alert = alt_bld.create();
		// Title for AlertDialog
		//alert.setTitle("Now press 'Press Me Again'!");
		alert.setTitle(this.getString(R.string.settingPageAlertTitleKey));
		// Icon for AlertDialog
		alert.setIcon(R.drawable.deskpetsicon);
		
		
		//if(buttonSoundAlert){
			alert.show();
			//buttonSoundAlert = false;
		//}
		
			
			//alert View end
    	
    }
    
    private void playSound(int testCode){
    	
    	System.out.println("!!!!!PLAY SOUND");
    	
    	mp.reset();
    	
    	int resid=R.raw.stopredbug;
    	
//    	MediaPlayer sound;
    	//sound = MediaPlayer.create(this, R.raw.stopredbug);
    	
    	AssetFileDescriptor afd;

//    	sound.setDataSource(this, uri);
    	try{
    		
    		if(testCode == 1){
    			resid = R.raw.stopredbug;
    		}
    		else if(testCode == 2){
    			resid = R.raw.stopredskitterflip;
    		}
    		
 
    		
    		//InputStream stream = this.getResources().openRawResource(resid); 
    		
    		
    		afd = this.getResources().openRawResourceFd(resid);  
    		
    		  if(afd != null){   
    		    mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());  
    		    afd.close();  
    		    mp.prepare();  
    		  }else {
    			  System.out.println("Not getting the location!!!!");
    			  
    		  }
    		  	  
    		//sound.setLooping(false);
    		
    	    mp.setLooping(false);
    		//if(playOrNot == 1){
    			////sound.start();
    			mp.start();
    		//	playOrNot = 0;
    		//}
    		//else{
    		//	TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("fuck "+ playOrNot);
    		
    		//}

    	}catch (Exception e) {
    		//TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("Error "+ playOrNot); 
    		System.out.println("EXCEPTION CAUGHT");
    		e.printStackTrace();
    		// serverPort = 80;  // default port for server 
        }
    	
    	mp.setOnCompletionListener(new OnCompletionListener() {

                 
      /*           public void onCompletion(MediaPlayer sound) {
                	 onDestroy();
                	 //sound.release();
                     TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("My double value is "+ product);
                     playOrNot = 1;
                 }*/
                 
                 public void onCompletion(MediaPlayer mp) {
                	 //onDestroy();
                	 //sound.release();
                	 mp.stop();
                	 
                    // TextView myTextView = (TextView) findViewById(R.id.textView1); myTextView.setText("On Completion My double value is "+ product);
                     playOrNot = 1;
                 }

             });
    		 
    		 
    	}
    
    @Override
    protected void onPause() {
        super.onPause();
 //       releaseMediaPlayer();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releaseMediaPlayer();

    }

    public void releaseMediaPlayer() {
        if (mp != null) {
            mp.release();
            //mp = null;
        }
    }
    
    
    
    
}
